<?php

require_once(dirname(__FILE__) . "/../website/configs/database.php");

if($_POST["password"] !== $_POST["confirmPassword"]){
    header("Location: register.php?message=Erreur confirm password");
}

$req = $db->prepare("SELECT * FROM user WHERE username = :pseudo");
$req->bindParam(":pseudo", $_POST["pseudo"]);   
$req->execute();

$result = $req->fetch(PDO::FETCH_ASSOC);

if($result){
    $message= "Compte existe déja";
    header("Location: register.php?message=$message");
}

if(!$result){
    $passwordToHash = $_POST["password"] . "YYirgzrfnd5ccdeULDheTdskXSZ";
    $hash = md5($passwordToHash);
    
    if(isset($_POST["role"])){
        $role = "studio";
    }else{
        $role = "artiste"; 
    }
    
    $req = $db->prepare("INSERT INTO user(username,password, role) VALUE(:username, :password, :role)");
    $req->bindParam(":username", $_POST["pseudo"]);
    $req->bindParam(":password", $hash);
    $req->bindParam(":role", $role);
    $req->execute();
    
    
    $message= "Compte créé";
    header("Location: login.php?message=$message&type=success"); 
}

