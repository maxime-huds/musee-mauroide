<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>

  <?php

session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}

require_once(dirname(__FILE__) . "/../website/configs/database.php");

$config = [
"STATUS" => ["created", "in_progress", "archived"]
];


?>

  <body class="bg-dark-subtle">
  

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-5">
  <div class="container-fluid">
    <img id="logo" src="https://static.vecteezy.com/system/resources/previews/009/384/601/original/headphones-clipart-design-illustartion-free-png.png" class="p-2">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Annonces</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="advert-list.php">Mes annonces</a>
        </li>
        <?php if($_SESSION["role"] === "studio") : ?>
        <li class="nav-item">
          <a class="btn btn-primary" href="advert-form.php">Ajouter une annonce</a>
        </li>
        <?php endif; ?>
        <?php if($_SESSION["role"] === "admin") : ?>
        <li class="nav-item">
          <a class="btn btn-primary" href="gestion.php">Gestion</a>
        </li>
        <?php endif; ?>
      </ul>
      <div class="collapse navbar-collapse justify-content-end">
        <div class="container">
          <a class="navbar-brand" href="user.php">
            <img src="https://cdn.pixabay.com/photo/2016/11/14/17/39/person-1824144_640.png" width="40" height="40">
          </a>
        </div>
        <a class="btn btn-warning" href="disconnect.php">Déconnexion</a>
      </div>
    </div>
  </div>
</nav>

<?php if($_SESSION["role"] === "artiste") : ?>
    <div class="container">
        <div class="card" style="width: 18rem;">
        <img src="https://media.istockphoto.com/id/1205771672/fr/vectoriel/jeune-homme-%C3%A9coutent-la-musique-sur-des-%C3%A9couteurs-musicoth%C3%A9rapie-profil-de-gars-avatar.jpg?s=170667a&w=0&k=20&c=wc2RveqdNQXZtmEmSE_d5B6fLOzPyvqUGbnsubTBLBQ=" class="card-img-top" alt="...">
        <div class="card-body">
            <h5 class="card-title" style="text-align: center;">🎉 Votre compte 🎉</h5>
            <p class="card-text">Nous sommes ravis de vous avoir parmis nos artistes !</p>
        </div>
        <ul class="list-group list-group-flush">
        <li class="list-group-item">Pseudo: <?php echo $_SESSION["username"]; ?></li>
            <li class="list-group-item">Role : Artiste</li>
            <form action="delete-account.php" method="post" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer votre compte ? Cette action est irréversible.');">
              <button class="btn btn-danger" type="submit">Supprimer mon compte</button>
            </form>
        </ul>
        </div>
    </div>
    <?php endif; ?>

    <?php if($_SESSION["role"] === "studio") : ?>
    <div class="container">
        <div class="card" style="width: 18rem;">
        <img src="https://cdn.dribbble.com/users/1104566/screenshots/14560607/media/ccbdf943b850e2534ecc7b4d3b4a1823.png?compress=1&resize=400x300&vertical=top">
        
        <div class="card-body">
            <h5 class="card-title" style="text-align: center;">🎉 Votre compte 🎉</h5>
            <p class="card-text">Nous sommes ravis de vous avoir parmis nos studios !</p>
        </div>
        <ul class="list-group list-group-flush">
        <li class="list-group-item">Pseudo: <?php echo $_SESSION["username"]; ?></li>
            <li class="list-group-item">Role : Studio</li>
            <form action="delete-account.php" method="post" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer votre compte ? Cette action est irréversible.');">
              <button class="btn btn-danger" type="submit">Supprimer mon compte</button>
            </form>
        </ul>
        </div>
    </div>
    <?php endif; ?>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>