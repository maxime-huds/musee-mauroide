
<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>

  <?php
    session_start();
    if(!isset($_SESSION["username"])){
      header("Location: login.php");
    }

    require_once(dirname(__FILE__) . "/../website/configs/database.php");

    $config = [
    "STATUS" => ["created", "in_progress", "archived"]
    ];

    
  ?>

  <body class="bg-dark-subtle">

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-5">
  <div class="container-fluid">
    <img id="logo" src="https://static.vecteezy.com/system/resources/previews/009/384/601/original/headphones-clipart-design-illustartion-free-png.png" class="p-2">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Annonces</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="advert-list.php">Mes annonces</a>
        </li>
        <?php if($_SESSION["role"] === "studio") : ?>
        <li class="nav-item">
          <a class="btn btn-primary" href="advert-form.php">Ajouter une annonce</a>
        </li>
        <?php endif; ?>
        <?php if($_SESSION["role"] === "admin") : ?>
        <li class="nav-item">
          <a class="btn btn-primary" href="gestion.php">Gestion</a>
        </li>
        <?php endif; ?>
      </ul>
      <div class="collapse navbar-collapse justify-content-end">
        <div class="container">
          <a class="navbar-brand" href="user.php">
            <img src="https://cdn.pixabay.com/photo/2016/11/14/17/39/person-1824144_640.png" width="40" height="40">
          </a>
        </div>
        <a class="btn btn-warning" href="disconnect.php">Déconnexion</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">

<h1>Mes annonces</h1>

<?php if($_SESSION["role"] === "artiste") : ?>

    <div class="row mt-5">
      <?php 

          # Récupération de l'auteur de l'annonce
          function getUser($author_id){
            global $db;

            $req = $db->prepare("SELECT * FROM user WHERE id = :author_id");
            $req->bindParam(":author_id", $author_id);
            $req->execute();

            return $result = $req->fetch(PDO::FETCH_ASSOC);
          }


        $studioReq = $db->prepare("SELECT studio_id, id FROM advert WHERE studio_id = :studio_id");
        $studioReq->bindParam(":studio_id", $_SESSION["id"]);
        $studioReq->execute();


        $advertReq = $db->prepare("SELECT id, title, description, image_url, location, author_id, DATE_FORMAT(created_at, '%d/%m/%Y à %H:%i') as created_at_format, status FROM advert WHERE studio_id = :studio_id ORDER BY created_at DESC");
        $advertReq->bindParam(":studio_id", $_SESSION["id"]);
        $advertReq->execute();

        while ($advertResult = $advertReq->fetch(PDO::FETCH_ASSOC)) {
            // Afficher les informations de l'annonce
            echo '<div class="col-md-4">';
            echo '<div class="card" style="width: 90%;">';
            echo '<img src="'.$advertResult["image_url"].'" class="card-img-top" alt="...">';
            echo '<div class="card-body">';
            echo '<a href="advert-page.php?id='.$advertResult["id"].'">';
            echo '<h5 class="card-title">'.$advertResult["title"].'</h5>';
            echo '</a>';
            echo '<p>';
            echo '<div class="card-text">';
            echo getUser($advertResult["author_id"])["username"];
            echo '<small class="text-muted">';
            echo $user["username"].' - '.$advertResult["location"];
            echo '</small>';
            echo '<br>';
            echo '<small class="text-muted">';
            echo $advertResult["created_at_format"];
            echo '</small>';
            echo '</div>';
            echo '</p>';
            echo '<p class="card-text">'.substr($advertResult["description"], 0, 100).' ...</p>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }

          
          ?>
    </div>
</div>

<?php endif ?>

<?php if($_SESSION["role"] === "studio") : ?>

  <div class="row mt-5">
      <?php 

          # Récupération de l'auteur de l'annonce
          function getUser($author_id){
            global $db;

            $req = $db->prepare("SELECT * FROM user WHERE id = :author_id");
            $req->bindParam(":author_id", $author_id);
            $req->execute();

            return $result = $req->fetch(PDO::FETCH_ASSOC);
          }


        $studioReq = $db->prepare("SELECT studio_id, id FROM advert WHERE studio_id = :studio_id");
        $studioReq->bindParam(":studio_id", $_SESSION["id"]);
        $studioReq->execute();


        $advertReq = $db->prepare("SELECT id, title, description, image_url, location, author_id, DATE_FORMAT(created_at, '%d/%m/%Y à %H:%i') as created_at_format, status FROM advert WHERE author_id = :id ORDER BY created_at DESC");
        $advertReq->bindParam(":id", $_SESSION["id"]);
        $advertReq->execute();

        while ($advertResult = $advertReq->fetch(PDO::FETCH_ASSOC)) {
            // Afficher les informations de l'annonce
            echo '<div class="col-md-4">';
            echo '<div class="card m-5" style="width: 25rem;">';
            echo '<img src="'.$advertResult["image_url"].'" class="card-img-top" alt="...">';
            echo '<div class="card-body">';
            echo '<a href="advert-page.php?id='.$advertResult["id"].'">';
            echo '<h5 class="card-title">'.$advertResult["title"].'</h5>';
            echo '</a>';
            echo '<p>';
            echo '<div class="card-text">';
            echo getUser($advertResult["author_id"])["username"];
            echo '<small class="text-muted">';
            echo $user["username"].' - '.$advertResult["location"];
            echo '</small>';
            echo '<br>';
            echo '<small class="text-muted">';
            echo $advertResult["created_at_format"];
            echo '</small>';
            echo '</div>';
            echo '</p>';
            echo '<p class="card-text">'.substr($advertResult["description"], 0, 100).' ...</p>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }

          
          ?>
    </div>

<?php endif ?>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>


    

    