<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>

  <?php

session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}

require_once(dirname(__FILE__) . "/../website/configs/database.php");

$config = [
"STATUS" => ["created", "in_progress", "archived"]
];


?>

  <body class="bg-dark-subtle">
  

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-5">
  <div class="container-fluid">
    <img id="logo" src="https://static.vecteezy.com/system/resources/previews/009/384/601/original/headphones-clipart-design-illustartion-free-png.png" class="p-2">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Annonces</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="advert-list.php">Mes annonces</a>
        </li>
        <?php if($_SESSION["role"] === "studio") : ?>
        <li class="nav-item">
          <a class="btn btn-primary" href="advert-form.php">Ajouter une annonce</a>
        </li>
        <?php endif; ?>
        <?php if($_SESSION["role"] === "admin") : ?>
        <li class="nav-item">
          <a class="btn btn-primary" href="gestion.php">Gestion</a>
        </li>
        <?php endif; ?>
      </ul>
      <div class="collapse navbar-collapse justify-content-end">
        <div class="container">
          <a class="navbar-brand" href="user.php">
            <img src="https://cdn.pixabay.com/photo/2016/11/14/17/39/person-1824144_640.png" width="40" height="40">
          </a>
        </div>
        <a class="btn btn-warning" href="disconnect.php">Déconnexion</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">
    <div class="row">
    
        <div class="col-md-12 text-bg-dark p-5 rounded">
        <h1 class="">Ajouter une annonce</h1>
            <form action="addAdvert.php" class="form-group p-5" method="post">
                <div class="form-group m-1">
                    <input type="text" name="title" class="form-control" placeholder="Entrez un titre">
                </div>
                <div class="form-group m-1">
                    <input type="text" name="image_url" class="form-control" placeholder="Entrez une url">
                </div>
                <div class="form-group m-1">
                    <textarea name="description" class="form-control" placeholder="Entrez une description"></textarea>
                </div>
                <div class="form-group m-1">
                    <select name="location" class="form-control">
                        <option value="">Sélectionnez une ville</option>
                        <option value="Montpellier">Montpellier</option>
                        <option value="Toulouse">Toulouse</option>
                        <option value="Béziers">Béziers</option>
                        <option value="Perpignan">Perpignan</option>
                        <option value="Nîmes">Nîmes</option>
                        <option value="Marseille">Marseille</option>
                        <option value="Lyon">Lyon</option>
                        <option value="Paris">Paris</option>
                        <option value="Bordeaux">Bordeaux</option>
                        <option value="Nice">Nice</option>
                        <option value="Lille">Lille</option>
                        <option value="Rennes">Rennes</option>
                        <option value="Strasbourg">Strasbourg</option>
                        <option value="Nantes">Nantes</option>
                        <option value="Grenoble">Grenoble</option>
                        <option value="Rouen">Rouen</option>
                        <option value="Saint-Étienne">Saint-Étienne</option>
                        <option value="Aix-en-Provence">Aix-en-Provence</option>
                        <option value="Clermont-Ferrand">Clermont-Ferrand</option>
                        <option value="Toulon">Toulon</option>
                    </select>
                </div>
                <input type="submit" value="Créer mon annonce" class="btn btn-primary">
            </form>
        </div>
    </div>


<?php if($_SESSION["role"] === "studio") : ?>

    <h1 class="mt-3">Mes archives</h1>

    <?php 

$searchTerm = $_GET['search'];

$req = $db->prepare("SELECT id, title, description, image_url, location, author_id, DATE_FORMAT(created_at, '%d/%m/%Y à %H:%i') as created_at_format, status FROM advert WHERE status = :status AND (title LIKE :searchTerm OR description LIKE :searchTerm) ORDER BY created_at DESC");
$req->bindParam(":status", $config["STATUS"][2]);
$req->bindValue(':searchTerm', '%' . $searchTerm . '%', PDO::PARAM_STR);
$req->execute();

if ($req->rowCount() > 0) {
  while ($result = $req->fetch(PDO::FETCH_ASSOC)) {
    // Afficher les informations de l'annonce
    echo '<div class="grid gap-3">';
    echo '<div class="row">';
    echo '<div class="col-md-4">';
    echo '<div class="card m-4" style="width: 300%;">';
    echo '<img src="'.$result["image_url"].'" class="card-img-top" alt="...">';
    echo '<div class="card-body">';
    echo '<a href="advert-page.php?id='.$result["id"].'">';
    echo '<h5 class="card-title">'.$result["title"].'</h5>';
    echo '</a>';
    echo '<p>';
    echo '<div class="card-text">';
    echo getUser($result["author_id"])["username"];
    echo '<small class="text-muted">';
    echo $user["username"].' - '.$result["location"];
    echo '</small>';
    echo '<br>';
    echo '<small class="text-muted">';
    echo $result["created_at_format"];
    echo '</small>';
    echo '</div>';
    echo '</p>';
    echo '<p class="card-text">'.substr($result["description"], 0, 100).' ...</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    
  }
} else {
  echo '<div class="alert alert-dark" role="alert">';
  echo "Aucune archive";  
  echo '</div>';
}
?>
<?php
endif
?>



</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>