<?php


session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}

require_once(dirname(__FILE__) . "/../website/configs/database.php");

// Vérifiez si l'ID de l'utilisateur à supprimer a été envoyé
if (isset($_POST['user_id'])) {
    $user_id = $_POST['user_id'];

    // Effectuez la requête pour supprimer l'utilisateur
    $req = $db->prepare("DELETE FROM user WHERE id = :user_id");
    $req->bindParam(':user_id', $user_id);
    $req->execute();

    $deleteAdvertsQuery = "DELETE * FROM advert WHERE author_id = :authorId";
    $deleteAdvertsStmt = $db->prepare($deleteAdvertsQuery);
    $deleteAdvertsStmt->bindValue(':authorId', $userId);
    $deleteAdvertsStmt->execute();

    // Redirigez l'utilisateur vers la page précédente
    header("Location: gestion.php?message=Utilisateur supprimer");
    exit();
}
