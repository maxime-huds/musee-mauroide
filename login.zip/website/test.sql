-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : ven. 13 oct. 2023 à 11:38
-- Version du serveur : 10.4.28-MariaDB
-- Version de PHP : 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `test`
--

-- --------------------------------------------------------

--
-- Structure de la table `advert`
--

CREATE TABLE `advert` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image_url` varchar(255) NOT NULL,
  `author_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `location` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `studio_id` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `advert`
--

INSERT INTO `advert` (`id`, `title`, `description`, `image_url`, `author_id`, `created_at`, `location`, `status`, `studio_id`) VALUES
(9, 'ElectrOzone', 'Studio d\'enregistrement ElectrOzone, situé près de Béziers et Montpellier, certifié Apple Digital Masters, vous accueille pour vos projets, Musicaux et Audiovisuels. \r\n\r\nGrâce à une cabine insonorisée, un parc de microphones de grandes marques, des préamplificateurs d\'excellence et une chaîne audio traitée avec soin, le studio vous garantit un enregistrement et une numérisation de haute qualité. \r\n\r\n \r\n\r\nNous assurons également la conception, le tournage et la post-production de vos projets vidéo.\r\n\r\nRéalisation de clip vidéo pour les groupes, orchestres, chanteur solo – Tous styles de musique. \r\n', 'https://static.vecteezy.com/ti/vecteur-libre/t2/6307611-magasin-de-musique-logo-template-eps-vectoriel.jpg', 1, '2023-06-01 21:12:17', 'Montpellier', 'in_progress', '1'),
(12, 'StudIOMeet', 'StudIOMeet est un studio d\'enregistrement professionnel conçu pour répondre aux besoins des artistes, producteurs et créateurs audio. Situé dans un environnement inspirant et équipé des dernières technologies, StudIOMeet offre un espace idéal pour la réalisation de projets musicaux, de voix off, de podcasts et bien plus encore.\r\n\r\nCaractéristiques et équipements :\r\n1. Environnement professionnel : StudIOMeet est conçu pour offrir une atmosphère professionnelle propice à la créativité et à la concentration. L\'agencement de l\'espace est optimisé pour créer une ambiance agréable et stimulante.\r\n\r\n2. Salle d\'enregistrement : Le studio dispose d\'une salle d\'enregistrement acoustiquement traitée pour garantir une qualité sonore optimale. Elle est équipée de microphones haut de gamme, de préamplis de qualité et d\'instruments de musique variés.\r\n\r\n3. Cabine d\'enregistrement : StudIOMeet propose également une cabine d\'enregistrement insonorisée pour les enregistrements vocaux, les voix off et les overdubs. La cabine offre une isolation sonore de haute qualité, permettant d\'obtenir des enregistrements clairs et sans bruit indésirable.\r\n\r\n4. Console de mixage : Un système de mixage professionnel est disponible dans le studio, permettant aux ingénieurs du son de réaliser des mixages précis et de qualité. La console est dotée de fonctionnalités avancées pour ajuster et équilibrer les différents éléments sonores.\r\n\r\n5. Monitoring de qualité : StudIOMeet est équipé d\'un système de monitoring de qualité supérieure, offrant une reproduction précise et fidèle du son. Cela permet aux artistes et aux ingénieurs du son d\'entendre chaque détail de leur travail avec une grande précision.\r\n\r\n6. Post-production : Le studio propose également des services de post-production, comprenant le mixage, le mastering, l\'édition et le traitement audio avancé. Ces services permettent d\'obtenir un son professionnel et prêt pour la diffusion.\r\n\r\n7. Espace de détente : StudIOMeet comprend également un espace de détente où les artistes peuvent se reposer, se détendre et échanger des idées. Cet espace offre un environnement convivial et confortable pour favoriser la collaboration et la créativité.\r\n\r\nQue vous soyez un musicien, un producteur, un podcasteur ou tout autre créateur audio, StudIOMeet offre un environnement professionnel et équipé pour répondre à vos besoins d\'enregistrement et de production. L\'équipe expérimentée du studio est là pour vous accompagner et vous fournir un soutien technique afin de concrétiser votre vision artistique.', 'https://free4kwallpapers.com/uploads/originals/2020/05/09/dj-headphones-by-mikael-kristenson-wallpaper.jpg', 10, '2023-06-02 20:59:20', 'Montpellier', 'created', NULL),
(16, 'HarmoniSound', 'Studio de musique créatif spécialisé dans la production de mélodies envoûtantes et de paysages sonores captivants.', 'https://d38kqrtdpvobsk.cloudfront.net/production/eb331ebf377c4294a5eaaefe9f0e5e4a/images/7b680c5f-0af8-47c3-905a-d87f3c6489a1.jpg', 1, '2023-06-03 19:14:10', 'Beziers', 'created', NULL),
(17, 'SonicLab', 'Un studio ultramoderne qui fusionne la science du son avec l\'art de la composition pour créer des expériences auditives uniques.', 'https://blog.groover.co/wp-content/uploads/2020/07/Capture-d%E2%80%99e%CC%81cran-2021-10-25-a%CC%80-17.32.17.jpg', 1, '2023-06-03 19:16:44', 'Montpellier', 'in_progress', '1'),
(18, 'MeloVibe', 'Un studio de musique expérimental qui explore les frontières du son et de la rythmique pour créer des compositions audacieuses et envoûtantes.', 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTv6NarpwXs47sd_tdPMseo-sCMYiwWePxCbQ&usqp=CAU', 10, '2023-06-03 19:17:57', 'Perpignan', 'in_progress', '1'),
(21, 'BeatLab', 'Un studio de production de musique électronique où les rythmes percutants et les basses profondes s\'unissent pour créer des morceaux qui font vibrer.', 'https://images.ctfassets.net/anpxw7hl9rcg/3gaqtY89LBT5n79QLAxcYI/8e5ee6a629969dd25710a2727edf67c3/rap-crew.webp', 1, '2023-06-03 21:32:09', 'Marseille', 'created', NULL),
(24, 'Mystic Owl Studios', 'Un studio novateur qui combine habilement différents styles musicaux pour créer des compositions uniques et percutantes qui transcendent les frontières.', 'https://images3.alphacoders.com/551/551126.jpg', 1, '2023-06-05 22:57:28', 'Montpellier', 'created', NULL),
(25, 'Pixelverse Productions', 'Un studio dédié à la création de mélodies captivantes et émotionnelles, conçues pour toucher les cœurs et stimuler l\'imagination.', 'https://wallpaperaccess.com/full/6802137.jpg', 10, '2023-06-05 23:00:34', 'Paris', 'archived', NULL),
(26, 'Whimsy', 'Un studio spécialisé dans la production de musiques apaisantes et harmonieuses, idéales pour la relaxation et la méditation.', 'https://images.wallpaperscraft.com/image/single/sound_recording_studio_music_166147_3840x2160.jpg', 10, '2023-06-05 23:02:31', 'Rouen', 'in_progress', '28'),
(28, 'FunnyStudio', 'FunnyStudio est un studio de production de films d\'action hilarants et de comédies déjantées. Situé dans un bâtiment coloré et excentrique, ce studio est réputé pour ses idées farfelues et son approche unique du divertissement.\r\n\r\nL\'équipe créative de FunnyStudio se compose de comédiens, de scénaristes et de réalisateurs délirants qui repoussent constamment les limites de l\'absurdité. Leurs productions sont connues pour leurs personnages loufoques, leurs situations comiques et leurs dialogues décalés.\r\n\r\nFunnyStudio se spécialise dans la réalisation de cascades comiques impressionnantes. Leurs équipes de cascadeurs professionnels sont formées pour effectuer des acrobaties extravagantes avec une touche d\'humour. Vous pouvez vous attendre à des scènes d\'action délirantes où les héros tombent, trébuchent et se retrouvent dans des situations loufoques.\r\n\r\nLe studio dispose également d\'un département d\'effets spéciaux spécialisé dans la création d\'explosions ridiculement exagérées, de poursuites loufoques et de transformations surréalistes. Leurs graphistes talentueux ajoutent des éléments visuels extravagants pour donner vie aux idées les plus farfelues.\r\n\r\nFunnyStudio est connu pour son atmosphère joyeuse et son esprit créatif sans limites. Les acteurs et l\'équipe travaillent ensemble dans une ambiance de franche camaraderie pour donner vie aux scénarios les plus fous. Les journées de tournage sont remplies de rires et de bonne humeur, ce qui se reflète dans le résultat final.\r\n\r\nSi vous cherchez des films qui vous feront éclater de rire et qui vous transportent dans un monde d\'absurdité, FunnyStudio est l\'endroit où aller. Attendez-vous à être surpris, amusé et à vivre une expérience cinématographique totalement décalée avec FunnyStudio !\r\n\r\n', 'https://www.gamstudio.com/data/documents/images/sliders/home/dsc_7920ok.jpg', 26, '2023-06-07 21:27:07', 'Grenoble', 'created', NULL);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `role`) VALUES
(1, 'julio', 'julio', 'artiste'),
(6, 'admin', 'be32527f6b0732be6f73e32665ea8dbf', 'admin'),
(9, 'test', 'e7d092eb25822f6c5bdd5b24abcb1121', 'artiste'),
(10, 'studio', '4c794cebb2d3d8336449b47d70316542', 'studio'),
(15, 'addon', '94e4f6040cb06b1066d60001262e51b6', 'studio'),
(16, 'madmat', 'f1703c2d437be0a51bc6483028fc5a2f', 'artiste'),
(29, 'oursdescavernes', 'f143717888fa1b7dbf6f060856b1a719', 'artiste');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `advert`
--
ALTER TABLE `advert`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `advert`
--
ALTER TABLE `advert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
