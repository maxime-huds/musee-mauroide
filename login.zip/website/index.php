
<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>

  <?php
    
session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}
if($_SESSION["role"] === "admin"){
  header("Location: gestion.php");
}

require_once(dirname(__FILE__) . "/../website/configs/database.php");

$config = [
"STATUS" => ["created", "in_progress", "archived"]
];

    
  ?>

  <body class="bg-dark-subtle">



  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-5">
  <div class="container-fluid">
    <img id="logo" src="https://static.vecteezy.com/system/resources/previews/009/384/601/original/headphones-clipart-design-illustartion-free-png.png" class="p-2">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Annonces</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="advert-list.php">Mes annonces</a>
        </li>
        <?php if($_SESSION["role"] === "studio") : ?>
        <li class="nav-item">
          <a class="btn btn-primary" href="advert-form.php">Ajouter une annonce</a>
        </li>
        <?php endif; ?>
        <?php if($_SESSION["role"] === "admin") : ?>
        <li class="nav-item">
          <a class="btn btn-primary" href="gestion.php">Gestion</a>
        </li>
        <?php endif; ?>
      </ul>
      <div class="collapse navbar-collapse justify-content-end">
        <div class="container">
          <a class="navbar-brand" href="user.php">
            <img src="https://cdn.pixabay.com/photo/2016/11/14/17/39/person-1824144_640.png" width="40" height="40">
          </a>
        </div>
        <a class="btn btn-warning" href="disconnect.php">Déconnexion</a>
      </div>
    </div>
  </div>
</nav>


<?php if(isset($_GET["message"])) : ?>

<div class="alert alert-warning alert-dismissible fade show" role="alert">
     <?=$_GET["message"];?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>


<?php endif ?>

<div class="container mb-4">

    <div id="carouselExampleSlidesOnly" class="carousel slide" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
        <img src="STUDIOMEET.png" class="img-fluid" >
          
        </div>
        <div class="carousel-item">
          <img src="festival1.png" class="d-block w-100">
        </div>
        <div class="carousel-item">
          <img src="festival2.png" class="d-block w-100" >
        </div>
      </div>
    </div>

</div>

<div class="container">

<h1>Liste des annonces</h1>

<div class="row">

<form action="index.php" method="GET" class="mb-3">
  <div class="input-group">
    <input type="text" class="form-control" name="search" placeholder="Rechercher une annonce">
    <input type="text" class="form-control" name="location" placeholder="Location">
    <button class="btn btn-dark" type="submit">Rechercher</button>
  </div>
</form>


<?php 

$searchTerm = $_GET['search'];

$searchTerm = $_GET['search'];
$locationTerm = $_GET['location'];

$req = $db->prepare("SELECT id, title, description, image_url, location, author_id, DATE_FORMAT(created_at, '%d/%m/%Y à %H:%i') as created_at_format, status FROM advert WHERE status = :status AND ((title LIKE :searchTerm OR description LIKE :searchTerm) AND location LIKE :locationTerm) ORDER BY created_at DESC");
$req->bindParam(":status", $config["STATUS"][0]);
$req->bindValue(':searchTerm', '%' . $searchTerm . '%', PDO::PARAM_STR);
$req->bindValue(':locationTerm', '%' . $locationTerm . '%', PDO::PARAM_STR);
$req->execute();


if ($req->rowCount() > 0) {
  while ($result = $req->fetch(PDO::FETCH_ASSOC)) {
    // Afficher les informations de l'annonce
    echo '<div class="grid gap-3">';
    echo '<div class="row">';
    echo '<div class="col-md-4">';
    echo '<div class="card m-4" style="width: 300%;">';
    echo '<img src="'.$result["image_url"].'" class="card-img-top" alt="...">';
    echo '<div class="card-body">';
    echo '<a href="advert-page.php?id='.$result["id"].'">';
    echo '<h5 class="card-title">'.$result["title"].'</h5>';
    echo '</a>';
    echo '<p>';
    echo '<div class="card-text">';
    echo getUser($result["author_id"])["username"];
    echo '<small class="text-muted">';
    echo " - ".$result["location"];
    echo '</small>';
    echo '</div>';
    echo '</p>';
    echo '<p class="card-text">'.substr($result["description"], 0, 100).' ...</p>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
    echo '</div>';
}
} else {
  echo '<div class="alert alert-dark" role="alert">';
  echo "Aucune recherche correspondante.";  
  echo '</div>';
}



?>
</div>

      <?php 

          # Récupération de l'auteur de l'annonce
          function getUser($author_id){
            global $db;

            $req = $db->prepare("SELECT * FROM user WHERE id = :author_id");
            $req->bindParam(":author_id", $author_id);
            $req->execute();

            return $result = $req->fetch(PDO::FETCH_ASSOC);
          }

          $req = $db->prepare("SELECT id, title, description, image_url, location,author_id,DATE_FORMAT(created_at, '%d/%m/%Y à %H:%i') as created_at_format,status FROM advert WHERE status = :status ORDER BY created_at DESC");
          $req->bindParam(":status", $config["STATUS"][0]);
          $req->execute(); 
        
      ?>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>

