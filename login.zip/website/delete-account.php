<?php

// Vérifier si l'utilisateur est connecté avec une session active
session_start();
if (!isset($_SESSION["id"])) {
    // Rediriger l'utilisateur vers la page de connexion ou afficher un message d'erreur
    header("Location: login.php");
    exit();
}

require_once(dirname(__FILE__) . "/../website/configs/database.php");

// Supprimer l'utilisateur de la base de données
$user_id = $_SESSION["id"];

$query = "DELETE FROM user WHERE id = :user_id";
$stmt = $db->prepare($query);
$stmt->bindParam(":user_id", $user_id);

if ($stmt->execute()) {
    // Suppression réussie
    session_destroy(); // Supprime la session pour déconnecter l'utilisateur
    header("Location: login.php?message=Compte supprimer"); // Redirige l'utilisateur vers une page de confirmation
    exit();
} else {
    // Erreur lors de la suppression
    echo "Erreur lors de la suppression du compte: " . $stmt->errorInfo()[2];
}

// Fermer la connexion à la base de données
$db = null;
?>
