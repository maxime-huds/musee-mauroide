<?php

require_once(dirname(__FILE__) . "/../website/configs/database.php");

session_start();

if($_GET["action"] === "archived"){
    $req = $db->prepare("UPDATE advert SET status = :status WHERE id = :advert_id");
    $req->bindParam(":status", $_GET["action"]);
    $req->bindParam(":advert_id", $_GET["advert_id"]);
    $req->execute();
 
}


if($_GET["action"] === "in_progress"){

    $req = $db->prepare("UPDATE advert SET status = :status, studio_id = :studio_id WHERE id = :advert_id");
    $req->bindParam(":status", $_GET["action"]);
    $req->bindParam(":advert_id", $_GET["advert_id"]);
    $req->bindParam(":studio_id", $_SESSION["id"]); 
    $req->execute();

}

if($_GET["action"] === "created"){

    $newStudioId = NULL;
    $req = $db->prepare("UPDATE advert SET status = :status, studio_id = :studio_id WHERE id = :advert_id");
    $req->bindParam(":status", $_GET["action"]);
    $req->bindParam(":advert_id", $_GET["advert_id"]);
    $req->bindParam(":studio_id", $newStudioId); 
    $req->execute();
    
}

header("Location: advert-page.php?id=" . $_GET["advert_id"]);