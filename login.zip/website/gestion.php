
<!doctype html>
<html lang="fr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>

  <?php

session_start();
if(!isset($_SESSION["username"])){
  header("Location: login.php");
}


require_once(dirname(__FILE__) . "/../website/configs/database.php");

$config = [
"STATUS" => ["created", "in_progress", "archived"]
];


?>

  <body class="bg-dark-subtle">
  

  <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-5">
  <div class="container-fluid">
    <img id="logo" src="https://static.vecteezy.com/system/resources/previews/009/384/601/original/headphones-clipart-design-illustartion-free-png.png" class="p-2">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
     
      <div class="ml-auto" style="display: flex;">
        <a class="btn btn-warning" href="disconnect.php">Déconnexion</a>
      </div>
    </div>
  </div>
</nav>

<div class="container">

<?php if(isset($_GET["message"])) : ?>

<div class="alert alert-warning alert-dismissible fade show" role="alert">
     <?=$_GET["message"];?>
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>


<?php endif ?>
  

<?php
// Récupérer le terme de recherche s'il est présent
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Construire la requête SQL avec le filtre de recherche
$sql = "SELECT id, username, password, role FROM user";
if (!empty($searchTerm)) {
    $sql .= " WHERE username LIKE :searchTerm";
}

$req = $db->prepare($sql);
if (!empty($searchTerm)) {
    $req->bindValue(':searchTerm', '%' . $searchTerm . '%');
}
$req->execute();

$results = $req->fetchAll(PDO::FETCH_ASSOC);
?>

<form method="get" action="">
    <div class="form-group" style="display: flex;">
        <input type="text" class="form-control" name="search" placeholder="Rechercher un pseudo" value="<?php echo $searchTerm; ?>">
        <button type="submit" class="btn btn-primary">Rechercher</button>
    </div>
   
</form>

<table class="table table-striped">
    <thead>
        <tr>
            <th>ID</th>
            <th>Pseudo</th>
            <th>Mot de passe</th>
            <th>Role</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($results as $row): ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['username']; ?></td>
                <td><?php echo $row['password']; ?></td>
                <td><?php echo $row['role']; ?></td>
                <td>
                    <form method="post" action="delete_user.php">
                        <input type="hidden" name="user_id" value="<?php echo $row['id']; ?>">
                        <button type="submit" class="btn btn-danger">Supprimer</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

</div>




<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>