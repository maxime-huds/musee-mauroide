<?php
session_start(); # On observe la session en cours

require_once(dirname(__FILE__) . "/../website/configs/database.php");# On inclus notre base de données présente dans le dossier "configs"

$config = [ # variables STATUS qui permet de faire une liste des status différents 
    "STATUS" => ["created", "in_progress", "archived"]
];

// Préparation de la requête
$req = $db->prepare('INSERT INTO advert(title, description, image_url, location, author_id, status, created_at) VALUES( :title, :description, :image, :location, :author_id, :status, NOW())');

// Liaison des paramètres
$req->bindParam(':title', $_POST['title']);
$req->bindParam(':description', $_POST['description']);
$req->bindParam(':image', $_POST['image_url']);
$req->bindParam(':location', $_POST['location']);
$req->bindParam(':author_id', $_SESSION["id"]);
$req->bindParam(':status', $config["STATUS"][0]);
$req->execute();

$id = $db->lastInsertId(); 

header("Location: advert-page.php?id=$id");

